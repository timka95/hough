# Copyright 2019-present NAVER Corp.
# CC BY-NC-SA 3.0
# Available only for non-commercial use

import pdb

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import math
import matplotlib.pyplot as plt

#from Class_losses.sampler_new import FullSampler

class MSELoss_new(nn.Module):
    """ Try to make the repeatability repeatable from one image to the other.
    """
    def __init__(self):
        nn.Module.__init__(self)
        self.name = 'difference'


    def forward(self, lines,lines_gt,batches_size, **kw):


        im_min = lines.view(batches_size, 1, -1).min(2)[0].view(batches_size,1,1,1)
        im_max = lines.view(batches_size, 1, -1).max(2)[0].view(batches_size,1,1,1)

        normalized_line = (lines - im_min) / (im_max - im_min + 1e-16)

        mse_mean = ((normalized_line - lines_gt) ** 2).view(batches_size, 1, -1).mean(2).mean()

        return mse_mean
        # plt.imshow(normalized_line[0,0,:,:].cpu().detach().numpy(), cmap='gray')


        # normalized_pred1 = (lines - lines.min()) / (lines.max() - lines.min() + 1e-16)
        # l = (normalized_pred1 - lines_gt) ** 2
        # # l = l.mean(dim=3).mean(dim=2).mean(dim=1)
        # l = l.mean()


        # sum_scc = 0
        # for k in range(10):
        #     l1 = (normalized_line[k] - lines_gt[k]) ** 2
        #     l1 = l1.mean()
        #     sum_scc = sum_scc + l1
        #
        # mm = sum_scc / 10
