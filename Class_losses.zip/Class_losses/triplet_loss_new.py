# Copyright 2019-present NAVER Corp.
# CC BY-NC-SA 3.0
# Available only for non-commercial use

import pdb
import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Variable
from sklearn.metrics import average_precision_score

class TripletLoss (nn.Module):

    def __init__(self):
        nn.Module.__init__(self)
        self.name = 'tripletloss'

    def distance_matrix_vector(self, f1, f2):
        """Given batch of anchor descriptors and positive descriptors calculate distance matrix"""

        MM = torch.mm(f1, torch.t(f2))
        #MM = f1 @ torch.t(f2)
        MM = (1 - MM) * 2
        return MM

    def forward(self, descriptors, Lins_HS, img_lines_idx, Lins_Matching , **kw):
        """HardNet margin loss - calculates loss based on distance matrix based on positive distance and closest negative distance.
        """

        #
        # Lins_HS = [ [91,30],[91,30],[91,30],[91,30],[91,30],[91,30],[91,30],[91,30],[91,30],[91,30]]
        # Lins_Matching = [ [0,1],[1,2],[3,4],[4,5],[5,6],[6,7],[8,9],[0,5],[0,6],[0,7]]
        # img_lines_idx = [[0],[1],[2],[3],[4],[5],[6],[7],[8],[9]] for each line from where it is coming
        #
        # list_Rho = Lins_HS[0, :, 0].long()
        # list_Theta = Lins_HS[0, :, 1].long()
        # #
        # list_img = img_lines_idx[0,:,0].long()
        # #
        # list_line_from = Lins_Matching[0,:,0].long()
        # list_line_to = Lins_Matching[0,:,1].long()


        # list_Rho = [i[0] for i in Lins_HS]
        # list_Theta = [i[1] for i in Lins_HS]
        # list_img = [i[0] for i in img_lines_idx]
        #
        # list_line_from = [i[0] for i in Lins_Matching]
        # list_line_to = [i[1] for i in Lins_Matching]

        Lins_HS = Lins_HS.cpu().detach().numpy()
        img_lines_idx = img_lines_idx.cpu().detach().numpy()
        Lins_Matching = Lins_Matching.cpu().detach().numpy()


        list_Rho = [[i[0]-1] for i in Lins_HS]
        list_Theta = [[i[1]-1] for i in Lins_HS]
        list_img = [[i[0]-1] for i in img_lines_idx]

        list_line_from = [[i[0]-1] for i in Lins_Matching]
        list_line_to = [[i[1]-1] for i in Lins_Matching]


        descriptor_lines =  descriptors[list_img,:,list_Rho,list_Theta][:,0,:]

        M_distance = self.distance_matrix_vector(descriptor_lines, descriptor_lines)
        M_distance.fill_diagonal_(10)

        positive_sets = M_distance[list_line_from,list_line_to]
        M_distance[list_line_from, list_line_to] = 10
        min_neg = M_distance[list_line_from,:].min(1)[0]

        loss = 1 + torch.tanh(positive_sets - min_neg)
        loss_mean = torch.mean(loss)/2
        return loss_mean
#plt.imshow(line_detected[0, 0, :, :].cpu().detach().numpy(), cmap='gray')

# class APLoss2 (nn.Module):
#     """ differentiable AP loss, through quantization.
#
#         Input: (N, M)   values in [min, max]
#         label: (N, M)   values in {0, 1}
#
#         Returns: list of query AP (for each n in {1..N})
#                  Note: typically, you want to minimize 1 - mean(AP)
#     """
#     def __init__(self, nq=25, min=0, max=1, euc=False):
#         nn.Module.__init__(self)
#
#
#     def compute_AP(self, x, label):
#
#         #average_precision_score(label, x)
#
#         sorted, indices = torch.sort(x, dim=-1, descending=True)
#         label.scatter_(dim=1, index=indices, src=label)
#         pos = torch.where(label == 1)
#         #ap = 1/(pos[:,1]+1)
#         ap = []
#
#         cloned_sorted = sorted.clone()
#         for i in range(0,sorted.shape[0]):
#             for j in range(0,sorted.shape[0]):
#                 cloned_sorted[i,j] = label[i,j]
#                 if cloned_sorted[i,j]==1:
#                     ap.append(1/(j+1))
#
#         AP = Variable(torch.FloatTensor(ap), requires_grad=True)
#         return AP
#
#     def forward(self, x, label):
#         assert x.shape == label.shape # N x M
#         return self.compute_AP(x, label)


